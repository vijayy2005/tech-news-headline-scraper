import requests
from bs4 import BeautifulSoup
from datetime import datetime

def fetch_headlines():
    url = 'https://news.ycombinator.com/'
    response = requests.get(url, timeout=10)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, 'html.parser')
    return [item.get_text(strip=True) for item in soup.select('.titleline a')]

def save_headlines(headlines):
    with open('output/tech_headlines.txt', 'w', encoding='utf-8') as file:
        file.write(f'Generated on: {datetime.now()}\n\n')
        for i, headline in enumerate(headlines, start=1):
            file.write(f'{i}. {headline}\n')

if __name__ == '__main__':
    headlines = fetch_headlines()
    save_headlines(headlines)
    print(f'Saved {len(headlines)} headlines successfully.')
