# Tech News Headline Scraper

Alternative submission version.
